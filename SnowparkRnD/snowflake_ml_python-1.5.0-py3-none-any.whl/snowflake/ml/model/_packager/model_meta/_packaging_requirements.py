REQUIREMENTS = [
    "cloudpickle>=2.0.0"
]
