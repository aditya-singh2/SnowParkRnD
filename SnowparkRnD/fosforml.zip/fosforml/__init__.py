# -*- coding: utf-8 -*-

from .api import register_model

from .decorators import scoring_func

__all__ = [
    'register_model'
]
