# -*- coding: utf-8 -*-

from .api import register_model


__all__ = [
    'register_model'
]
