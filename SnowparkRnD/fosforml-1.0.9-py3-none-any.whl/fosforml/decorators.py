# -*- coding: utf-8 -*-
# please don't remove this. This is to inject scoring_func dependency
from mosaic_utils.ai.decorators import scoring_func
